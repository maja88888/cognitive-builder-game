# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Artifacts

### Barnspel (kids educational game) — `/`
A Swedish educational app "Cognitive Builder" for children aged 3–9. React + Vite frontend, connects to the API server for Teacher Mode and class data.

**Features:**
- 3 age groups: 3–5 Småbarn, 6–7 Förskoleklass, 8–9 Lågstadiet
- 6 themes (Dinosaurier, Rymden, Prinsessor, Fordon, Djur, Superhjältar)
- 13 games total across all age groups
- Sticker rewards every 3 correct answers
- Personal best timer (8–9 group)
- Parent progress dashboard
- Teacher Mode (code: LARARE123): class management, per-student progress, status table, weekly summary email, IUP CSV export
- Class code flow: students can optionally enter name + class code to link gameplay to a class (stored in localStorage as `cb_student`)
- Progress logging: `recordResult()` in `src/lib/progress.ts` saves to localStorage AND silently POSTs to API when a student session exists
- Professional "Cognitive Builder" design: Nunito font, #6C5CE7 primary, Material Icons Round

**Games included:**
- **Färger** (Colors): Match a named color to the correct colored circle. Tracks streaks.
- **Räkna** (Count): Count animals that appear one by one and select the correct number (1–6).
- **Mönster** (Patterns): Identify what comes next in a repeating pattern (AB, AAB, ABC). Difficulty increases with streaks.
- **Sortera** (Sort): Sort items into categories (Animals, Food, Vehicles).
- **Minne** (Memory): Classic card matching game with emoji pairs.

**Features:**
- Score tracking with badge progression (Nybörjare → Stjärna → Superstjärna → Mästare → Kung/Drottning)
- Star burst particle celebration effects on correct answers
- Difficulty scaling (pattern game levels up with streak)
- Encouraging Swedish feedback messages
- Large touch-friendly buttons suitable for small children

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
